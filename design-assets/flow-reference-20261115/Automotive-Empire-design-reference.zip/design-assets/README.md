# Automotive Empire — referencias visuales de Google Flow

Dirección artística del 15 de noviembre de 2026. Abrir **GALERIA.html** para ver las selecciones y desplegar las alternativas de cada pantalla. No requiere cuenta, dependencias ni conexión a Flow: utiliza los originales guardados en este paquete.

## Contenido

- `01-inicio/`: cuatro exploraciones y una iteración del garaje fundador.
- `02-headquarters/`: campus, edificio seccionado, mapa y plaza.
- `03-taller/`: cuatro propuestas de editor modular de autos.
- `04-fabrica/`: cuatro propuestas de planta y producción.
- `05-garaje/`: cuatro propuestas de colección y personalización.
- `06-cofres/`: cuatro propuestas de inventario y recompensa.
- `07-configuracion/`: cuatro propuestas de ajustes.
- `handoff/IMPLEMENTACION.md`: contrato visual, colores, tipografía, comportamientos y sistema de piezas.
- `handoff/layout.json`: rectángulos, acciones y regiones de siete pantallas en lienzo normativo 1920×1080.
- `handoff/COMPARACION.md`: comparación de calidad, estilo, composición, legibilidad y factibilidad en React.
- `manifest.json`: dimensiones reales, formato, SHA-256 y archivo elegido por pantalla.
- `generation-log.json`: prompts exactos, correspondencia con los originales descargados y problemas del proceso.

## Selecciones de dirección artística

| Pantalla | Selección | Motivo y corrección pendiente |
|---|---|---|
| Inicio | E, iteración de D | Garaje fundador, menú claro y auto protagonista. Suavizar sombra y conservar proporciones de la referencia original. |
| Headquarters | A | Campus explorable con destinos reconocibles. Simplificar barra, sustituir números ficticios y rótulos. |
| Taller | A | Auto grande, categorías y piezas ordenadas. Producir capas y anclajes reales; B guía accesorios SUV y D el interior. |
| Fábrica | A | Flujo lateral claro en cuatro estaciones. Traducir rótulos y separar máquinas, progreso y vehículos. |
| Garaje | A | Colección visible sin quitar protagonismo al auto. Unificar vehículos con taller y reemplazar datos inventados. |
| Cofres | B | Mejor escena de recompensa. A guía el estado cerrado; unificar ambas cajas y convertir cartas/textos en elementos vivos. |
| Configuración | A | Panel navy coherente con inicio; opciones legibles. Generalizar pestañas y usar preferencias reales. |

## Qué está y qué falta

Son referencias de pantalla aplanadas, generadas y examinadas visualmente. No son piezas transparentes ni fondos limpios; no se implementó React ni se comprobó todavía una reproducción exacta en el juego. La tipografía y las coordenadas del handoff son decisiones normativas, no supuestas fuentes/mediciones extraídas mágicamente de un JPEG. Las selecciones corresponden al director artístico y quedan disponibles para revisión del usuario.

Flow mostró **0 créditos** en la configuración seleccionada: Nano Banana 2.1, imagen, 16:9, razonamiento alto, una salida por prompt. Hubo bloqueos intermitentes «Detectamos actividad inusual». El usuario intervino para recuperar el taller; luego pidió escribir y enviar más lento. Se pasó a una generación por vez y se verificaron los resultados antes del siguiente envío. No se contrataron servicios ni se activaron opciones pagas.

Los originales conservan su resolución real, registrada en el manifiesto. No son 1920×1080 por el solo hecho de que el prompt lo pidiera. Se descargaron sin retoque ni reescalado. El cambio de extensión de .jfif a .jpg no cambia los bytes JPEG.

## Para Claude Code

1. Leer `handoff/IMPLEMENTACION.md`, `layout.json`, el manifiesto y la comparación.
2. Abrir las siete imágenes elegidas, no reconstruirlas a partir de prompts.
3. Trabajar en rama independiente; no modificar main ni fusionar PRs.
4. Producir fondos sin interfaz, autos aislados y piezas compatibles antes de prometer personalización modular completa.
5. Construir UI viva con Barlow Condensed e Inter, colores y posiciones del contrato.
6. Comparar capturas de la implementación con los originales y corregir diferencias de silueta, jerarquía y espacios.

La rama usada como base de preparación es `phase5b-premium-2d-art-direction` en el commit `0324f3bb8e1ebe051ed61177a4df205fd3151025`. Esta entrega redefine el objetivo visual con referencias bitmap; no da por aprobados los SVG actuales ni modifica la simulación.
