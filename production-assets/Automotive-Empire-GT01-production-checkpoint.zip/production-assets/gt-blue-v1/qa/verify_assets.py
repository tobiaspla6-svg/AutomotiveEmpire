"""Inspect actual raster alpha and compare edits against a frozen car image.

This is verification only. It does not invent pieces, remove backgrounds,
register/reposition edits, or change source images to conceal geometry drift.
"""
from pathlib import Path
import argparse, hashlib, json
import cv2
import numpy as np
from PIL import Image, ImageDraw

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SOURCE=ROOT/'sources/user-gt-blue-original.jpg'

def inspect(path):
    raw=path.read_bytes()
    with Image.open(path) as im:
        rgba=np.asarray(im.convert('RGBA'))
        result={'file':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),'dimensions':list(im.size),'format':im.format,'mode':im.mode,'sha256':hashlib.sha256(raw).hexdigest(),'hasAlphaChannel':'A' in im.getbands(),'transparentPixelCount':int((rgba[:,:,3]==0).sum()),'partialAlphaPixelCount':int(((rgba[:,:,3]>0)&(rgba[:,:,3]<255)).sum()),'hasActualTransparency':bool((rgba[:,:,3]<255).any())}
    return result

def wheels(path):
    gray=cv2.cvtColor(cv2.imread(str(path)),cv2.COLOR_BGR2GRAY)
    result={}
    # These search windows are for the original native canvas, not every model.
    for name,(x,y,w,h) in {'front':(215,375,215,215),'rear':(950,375,215,215)}.items():
        tile=cv2.GaussianBlur(gray[y:y+h,x:x+w],(5,5),0)
        cs=cv2.HoughCircles(tile,cv2.HOUGH_GRADIENT,1,100,param1=100,param2=32,minRadius=85,maxRadius=105)
        if cs is None:
            result[name]={'detected':False};continue
        cx,cy,r=map(float,cs[0][0]);result[name]={'detected':True,'cx':round(cx+x,2),'cy':round(cy+y,2),'radius':round(r,2)}
    return result

def reference_report():
    result=inspect(SOURCE);result['wheels']=wheels(SOURCE)
    result['measurement']='Hough-circle tire contour estimates; uncertainty approx ±3 native px. Visually reviewed. Not CAD dimensions.'
    result['productionTarget']={'width':1600,'height':700,'operation':'uniform scale and translation only; not exported yet','scale':7/6,'offsetX':-8/3,'offsetY':590-(478.5+92.1)*7/6,'groundLine':590}
    result['status']='referencia'
    result['modularComposition']={'status':'not_run','reason':'No aligned generated component files available yet.'}
    im=Image.open(SOURCE).convert('RGB');d=ImageDraw.Draw(im)
    for name,w in result['wheels'].items():
        if w['detected']:
            x,y,r=w['cx'],w['cy'],w['radius'];d.ellipse((x-r,y-r,x+r,y+r),outline='#ff3b7b',width=2);d.line((x-12,y,x+12,y),fill='#ff3b7b',width=2);d.line((x,y-12,x,y+12),fill='#ff3b7b',width=2);d.text((x-64,y+r+12),f'{name}: {x}, {y}',fill='#172630')
    d.line((60,570.6,1316,570.6),fill='#2aa0a0',width=2)
    im.save(HERE/'source-wheel-measurements.png')
    (HERE/'source-geometry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

def compare(base,variant,roi):
    bi,vi=inspect(base),inspect(variant)
    result={'base':bi,'variant':vi,'allowedEditRect':roi,'sameCanvas':bi['dimensions']==vi['dimensions'],'geometryPassed':False,'status':'pendiente de corrección'}
    if not result['sameCanvas']:
        result['reason']='Canvas differs: no resizing or registration is applied to hide drift.';return result
    b=np.asarray(Image.open(base).convert('RGBA'));v=np.asarray(Image.open(variant).convert('RGBA'))
    # Compare RGB over white to avoid differences from invisible RGB channels.
    def white(a):
        alpha=a[:,:,3:4].astype(float)/255
        return a[:,:,:3]*alpha+255*(1-alpha)
    diff=np.abs(white(b)-white(v));outside=np.ones(b.shape[:2],dtype=bool)
    x0,y0,x1,y1=roi;outside[y0:y1,x0:x1]=False
    result['outsideEditMeanAbsoluteError']=round(float(diff[outside].mean()),4)
    result['outsideEditPixelsChangedOver8']=int((diff.max(2)[outside]>8).sum())
    bw,vw=wheels(base),wheels(variant);result['baseWheelFits']=bw;result['variantWheelFits']=vw
    drift=[]
    for name in ('front','rear'):
        if bw[name]['detected'] and vw[name]['detected']:
            drift.append(float(np.hypot(bw[name]['cx']-vw[name]['cx'],bw[name]['cy']-vw[name]['cy'])))
    result['wheelCenterDriftPx']=[round(a,3) for a in drift]
    result['geometryPassed']=len(drift)==2 and max(drift)<=2 and result['outsideEditPixelsChangedOver8']==0
    result['numericChecksPassed']=result['geometryPassed'] and vi['hasActualTransparency']
    result['visualReviewRequired']=True
    result['status']='pendiente de corrección'
    result['approvalNote']='Numeric checks alone do not approve an asset; inspect the actual composition and alpha edges before promotion.'
    # This is a QA overlay, not a reconstructed or corrected modular asset.
    Image.blend(Image.open(base).convert('RGB'),Image.open(variant).convert('RGB'),0.5).save(HERE/(variant.stem+'-overlay-50.png'))
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path);ap.add_argument('--variant',type=Path);ap.add_argument('--roi',nargs=4,type=int);args=ap.parse_args()
    if args.base and args.variant and args.roi:
        report=compare(args.base,args.variant,args.roi);out=HERE/(args.variant.stem+'-comparison.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    else: report=reference_report()
    print(json.dumps(report,ensure_ascii=False))
